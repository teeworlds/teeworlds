This is the first playable beta version of Teewars.

Keys
####

A and D to move left and right
W or Space to jump
Left mouse button fires your weapon
Right mouse button launches the grappling hook
1-5 to change weapon


Gameplay
########

Players spawn with the Sledge Hammer and the Gun, which has unlimited ammo. All other weapons hold 10 rounds.


Command Line Switches
####################

-s to start a server
-w for windowed mode
	

The Teewars team
################

Matricks	Code
Phobos		Code
Serp		Code
Void		Code
Red Com		Graphics
Ampleyfly	Graphics
Maikka		Graphics
Dopefish	Levels
Teetow		Audio
Trin		Web page


Contact info
############

http://www.teewars.com
Any bugs or problems can be addressed in #teewars on Quakenet IRC.